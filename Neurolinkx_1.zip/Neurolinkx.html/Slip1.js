// On dashboard.js after balance updates
localStorage.setItem('userBalance', balance);

// On dashboard load
let storedBalance = parseInt(localStorage.getItem('userBalance')) || 0;
balance = storedBalance;
balanceDisplay.textContent = `Balance: ₦${balance.toLocaleString()}`;