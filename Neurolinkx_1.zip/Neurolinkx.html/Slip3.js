document.getElementById('bankForm').addEventListener('submit', e => {
  e.preventDefault();
  const amount = parseInt(document.getElementById('amount').value);
  let current = parseInt(localStorage.getItem('userBalance')) || 0;
  localStorage.setItem('userBalance', current + amount);
  alert(`₦${amount.toLocaleString()} bank deposit submitted! Pending approval.`);
  window.location.href = 'dashboard.html';
});