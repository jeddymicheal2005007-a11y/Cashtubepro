let current = parseInt(localStorage.getItem('userBalance')) || 0;
localStorage.setItem('userBalance', current + amount);
window.location.href = 'dashboard.html';