// Load balance from localStorage dynamically
let balance = parseInt(localStorage.getItem('userBalance')) || 0;
balanceDisplay.textContent = `Balance: ₦${balance.toLocaleString()}`;

// Watch for changes in localStorage (from Top-Up page)
window.addEventListener('storage', () => {
    balance = parseInt(localStorage.getItem('userBalance')) || 0;
    balanceDisplay.textContent = `Balance: ₦${balance.toLocaleString()}`;
});